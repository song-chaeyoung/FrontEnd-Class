import "./App.css";
import Header from "./components/Header";
import TodoEditor from "./components/TodoEditor";
import Todolist from "./components/todolist";

function App() {
  return (
    <div className="App">
      <Header />
      <TodoEditor />
      <Todolist />
    </div>
  );
}

export default App;
